import React, {Component} from "react";

export default class LoginPage extends Component {
  render() {
    return (
      <div>
        <h3>LoginPage</h3>
      </div>
    );
  }
}
