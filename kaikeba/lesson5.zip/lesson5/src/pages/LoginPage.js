import {Component} from "react";
import {Redirect} from "react-router-dom";
import {connect} from "react-redux";
import {login} from "../action/user";

// mapStateToProps
// mapDisaptchToProps
@connect(
  ({user}) => ({isLogin: user.isLogin, loading: user.loading, err: user.err}),
  {login}
)
class LoginPage extends Component {
  constructor(props) {
    super(props);
    this.state = {name: ""};
  }
  render() {
    const {isLogin, location, dispatch, login, loading, err} = this.props;
    // 已经登录了
    if (isLogin) {
      const {redirect = "/"} = location.state || {};
      return <Redirect to={redirect} />;
    }

    // 没有登录
    const {name} = this.state;
    return (
      <div>
        <h3>LoginPage</h3>
        <input
          type="text"
          name=""
          id=""
          value={name}
          onChange={(e) => this.setState({name: e.target.value})}
        />
        <button onClick={() => login({name})}>
          {loading ? "loading" : "login"}
        </button>
        <p className="red">{err.msg}</p>
      </div>
    );
  }
}
export default LoginPage;
