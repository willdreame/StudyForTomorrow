import Routes from "./routes";

export default function App(props) {
  return <Routes />;
}
