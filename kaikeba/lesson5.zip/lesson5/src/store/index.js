import {createStore, combineReducers, applyMiddleware} from "redux";
import {loginReducer} from "./loginReducer";
import thunk from "redux-thunk";
import createSagaMiddleware from "redux-saga";
import loginSaga from "../action/loginSaga";

// import rootSaga from "../action/rootSaga";

const sagaMiddleware = createSagaMiddleware();

const store = createStore(
  combineReducers({user: loginReducer}),
  applyMiddleware(thunk, sagaMiddleware)
);

// redux-saga帮助我们执行generator函数
sagaMiddleware.run(loginSaga);

export default store;
