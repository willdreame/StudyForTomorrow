import doc from "./doc.md";

console.log(doc);
