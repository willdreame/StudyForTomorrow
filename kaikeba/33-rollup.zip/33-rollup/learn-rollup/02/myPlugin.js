export function myPlugin() {
  return {
    name: "my-cxr-plugin",
    //     buildStart(options){
    // 	    console.log(options)
    //     },
    //     resolveId(source) {
    // 	    console.log("resolveId ->:",source)
    //     },

    //     load(id, source) {
    // 	if(id.endsWith(".md")){
    // 		// 自己去加载

    // 	}
    //     },
    // async
    transform(code,id) {
      console.log("source", source);
      // TODO
      // 如何把 source  .md -> html
      //
//       remark()
//         .use(remarkPresetLintRecommended)
//         .use(remarkHtml)
//         .process("## Hello world!")
//         .then((file) => {
//           console.error(reporter(file));
//           console.log(String(file));
//         });

//       return "export default `123`";
    },
  };
}
