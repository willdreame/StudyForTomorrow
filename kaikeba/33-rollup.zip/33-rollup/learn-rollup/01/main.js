import { foo } from "./foo";
// import answer from "the-answer";
// import axios from "axios";
import _ from "lodash";
console.log(_);

// lodash
// 1. 你想要把 在 node_modules 里面的包 打包到你自己的bundle.js 内的话
// rollup -> esm
// axios  -> cjs
// error????

// cjs -> esm
// commonjs

console.log(axios);

console.log(answer);


// es5
export default ()=>{
	console.log("main.js")
}
