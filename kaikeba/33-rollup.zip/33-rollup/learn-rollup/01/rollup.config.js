import json from "@rollup/plugin-json";
import { nodeResolve } from "@rollup/plugin-node-resolve";
import commonjs from "@rollup/plugin-commonjs";
import { babel } from "@rollup/plugin-babel";

// import { terser } from "rollup-plugin-terser";
// esm -> nodejs type -> modules default

// rollup -> esm
// node_modules -> cjs 又会报错

export default {
  input: "./main.js",
  output: {
    file: "dist/bundle.cjs.js",
    format: "cjs",
  },
  //   output: {
  //     dir: "dist",
  //   },
  //   output: [
  //     {
  //       file: "dist/bundle.cjs.js",
  //       format: "cjs", //
  //     },
  //     {
  //       file: "dist/bundle.esm.js",
  //       format: "esm", //
  //     },
  //     {
  //       file: "dist/bundle.esm.min.js",
  //       format: "esm", //
  //       plugins: [terser()],
  //     },
  //   ],
  plugins: [json(), nodeResolve(), babel(), commonjs()],
  external: ["lodash"],
};
