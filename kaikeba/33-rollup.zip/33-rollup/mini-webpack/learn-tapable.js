const { SyncHook } = require("tapable");

class Car {
  constructor() {
    this.users = [];
    this.hooks = {
      accelerate: new SyncHook(["car"]),
    };
  }

  addUser(user) {
    this.users.push(user);
  }

  toJSON() {
    //   this.users -> json
    console.log(this.users)
  }
}

const car = new Car();

// tap = addEvent 注册一个事件
car.hooks.accelerate.tap("WarningLampPlugin", (car) => {
  //   console.log("123");
  //   console.log("speed", speed);
  // 是不是就是一个扩展
  car.addUser("cxr");
});

car.hooks.accelerate.call(car);

car.toJSON()
