import { foo } from "./foo.js";
import doc from './doc.md'

console.log("main.js");
console.log(doc)
foo();



export default "123"
