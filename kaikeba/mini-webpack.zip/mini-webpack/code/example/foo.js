
export function foo() {
  console.log("foo");
}

