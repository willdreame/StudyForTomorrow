import css from "./style/index.less";
import pic from "./images/logo.png";

console.log("hello loader");

// const img = new Image();

// img.src = pic;

// const tag = document.getElementById("app");
// tag.append(img);

// 静态资源
// 图片 第三方字体文件
// 资源压缩 优化 image-webpack-loader//有坑
// 图片资源的使用场景
// html img
// css 背景图
// js dom

// 多页面打包的通用解决方案
