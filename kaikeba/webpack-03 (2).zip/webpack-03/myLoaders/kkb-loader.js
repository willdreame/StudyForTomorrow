module.exports = function (source) {
  const result = source.replace("hello", "您好");

  return result;
};
