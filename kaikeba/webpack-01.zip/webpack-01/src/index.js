import { str } from "./b.js";
import css from "./index.css";
// import pic from "./users.png";
console.log("我是Index");

// 启动webpack

// loader
// webpack默认只支持.js .json类型的模块
