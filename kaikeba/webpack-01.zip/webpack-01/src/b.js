export const str = "hello";
