// export const str = "hello";
console.log("我是A");
