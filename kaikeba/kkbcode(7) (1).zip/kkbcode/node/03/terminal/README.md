# 界面简单试验环境

前后端通用入口 

## 调试
Start dev server:
    npm run dev

## 启动   
    npm start


## 功能
- 调用lib/api中的方法
- 直接执行终端命令 大家可以用ls试验一下