// css 序列化
module.exports = function (source) {
  return JSON.stringify(source);
};
