module.exports = function (source) {
  return source.replace("hello", "您好");
};

// 自定义loader的路径问题
