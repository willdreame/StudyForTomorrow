module.exports = {
  plugins: [require("autoprefixer"), require("cssnano")], //目标浏览器的环境
};
