import 'dart:convert';
import 'dart:io';
import 'package:course3/PageHome.dart';
import 'package:course3/PageSearch.dart';
import 'package:course3/PageMy.dart';
import 'package:course3/PageWebView.dart';
import 'package:course3/models/IconFontIcons.dart';
import 'package:dio/dio.dart';

import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(primarySwatch: Colors.blue,
      ),
      initialRoute: "/",
      routes: {
        "/":(BuildContext context)=>MyHomePage(title: 'Flutter Demo Home Page'),
        "/search":(BuildContext context){
          return PageSearch();
        },
        "/my":(BuildContext context){
          print("go page my");
          return PageMy();
        },
        "/webview":(BuildContext context){
          print("go page webview");
          return PageWebView(url: "https://c.runoob.com/compile/1");
        },
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

int currentTabIndex= 0;

class _MyHomePageState extends State<MyHomePage> {

  PageController _pageController = PageController();

  int currentBottomTabIndex = 0;

  late List<Widget> pages;

  @override
  void initState() { 


    pages = [
      new PageHome(),
      new PageSearch(),
      new PageMy()
    ];

    super.initState();
    
  }

  //切换到哪个时，哪个页面才构建
  //保持原页面的状态，再次切换的时候不重新构建
  

  Widget getBodyPage(){
    //pageView = swiper
    return PageView(
      physics: NeverScrollableScrollPhysics(),
      controller: _pageController,
      children: pages,
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: getBodyPage(),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (int bottomTabIndex){
          
          setState(() {
            currentBottomTabIndex = bottomTabIndex;
            _pageController.jumpToPage(currentBottomTabIndex);
          });
        },
        currentIndex: currentBottomTabIndex,
        selectedItemColor:Colors.red,
        items: [
          //material design里的icons
          //image icon
          //image.network/asset/file/emoryImage
          BottomNavigationBarItem(icon: ImageIcon(AssetImage("assets/images/piechart-circle-fil.png")),label: "首页"),
          BottomNavigationBarItem(icon: Icon(IconFontIcons.iconStarFill),label:"发现"),
          BottomNavigationBarItem(icon: Icon(IconFontIcons.iconSwap),label:"我的")
        ]
      ),
    );
  }
}
