import 'package:course3/PageMy.dart';
import 'package:course3/PageWebView.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


class PageSearch extends StatefulWidget {
  PageSearch({Key? key}) : super(key: key);

  @override
  _PageSearchState createState() => _PageSearchState();
}

class _PageSearchState extends State<PageSearch> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;
  
  @override
  Widget build(BuildContext context) {
    print("发现页面build了");

    return Scaffold(
      appBar: AppBar(title:Text("发现")),
      body: Center(
        child:ElevatedButton(onPressed: (){
          // Navigator.pushNamed(context, "/webview");
          Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
            return PageWebView(url: "https://c.runoob.com/");
          }));
        }, child: Text("显示网页"))
      ),
    );
  }
}