import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class PageHome extends StatefulWidget {
  PageHome({Key? key}) : super(key: key);

  @override
  _PageHomeState createState() => _PageHomeState();
}

//<keepalive></keepalive>
class _PageHomeState extends State<PageHome> with AutomaticKeepAliveClientMixin {
  
  

  int currentTabIndex = 0;
  List<String> tabTitles= ["关注","推荐","热门","iOS","android","前端","后端"];


  List<Widget> getAllTabs(){
    List<Widget> list = [];
    for(int i=0;i<tabTitles.length;i++){
      list.add(Tab(text:tabTitles[i]));
    }
    return list;
  }

  List<Widget> getAllTabViews(){
    List<Widget> list = [];
    for(int i=0;i<tabTitles.length;i++){
      list.add(Center(child:Text(tabTitles[i])));
    }
    return list;
  }
  
  @override
  Widget build(BuildContext context) {
    print("首页build了");

    return DefaultTabController(
      length: tabTitles.length, 
      child: Scaffold(
      appBar: AppBar(
        title: Text("flutter25期"),
        leading: IconButton(icon:Icon(Icons.home),onPressed: (){},),
        actions: [
          IconButton(icon:Icon(Icons.add),onPressed: (){}),
        ],
        bottom: TabBar(
          indicatorColor: Colors.red,
          isScrollable: true,
          tabs: getAllTabs(),
        ),
      ),
      body: TabBarView(
          children: getAllTabViews()
        ),
    )
    );
  }

  @override
  bool get wantKeepAlive => true;
}