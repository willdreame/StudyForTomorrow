import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class PageMy extends StatefulWidget {
  PageMy({Key? key}) : super(key: key);

  @override
  _PageMyState createState() => _PageMyState();
}

class _PageMyState extends State<PageMy> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;
  
  @override
  Widget build(BuildContext context) {

    print("我的页面build了");

    return Scaffold(
      appBar: AppBar(title:Text("我的")),
      body: Center(
        //shop/product/specselctor
        child:ElevatedButton(onPressed: (){
          Navigator.pop(context);
        }, child: Text("返回"))
      ),
    );
  }
}