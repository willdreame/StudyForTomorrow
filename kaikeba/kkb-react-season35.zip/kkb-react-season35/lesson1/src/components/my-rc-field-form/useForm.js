import { useRef } from "react";

class FormStore {
  constructor() {
    //数据仓库
    this.store = {};
    // 存储field实例
    this.fieldEntities = [];

    // 存储回调
    this.callbacks = {};
  }

  setCallbacks = (newCallbacks) => {
    this.callbacks = {
      ...this.callbacks,
      ...newCallbacks,
    };
  };

  registerFieldEntities = (entity) => {
    this.fieldEntities.push(entity);

    return () => {
      this.fieldEntities = this.fieldEntities.filter((item) => item !== entity);
      delete this.store[entity.props.name];
    };
  };

  getFieldsValue = () => {
    return { ...this.store };
  };

  getFieldValue = (name) => {
    return this.store[name];
  };

  setFieldsValue = (newStore) => {
    this.store = {
      ...this.store,
      ...newStore,
    };

    // 需要组件更新
    this.fieldEntities.forEach((entity) => {
      Object.keys(newStore).forEach((key) => {
        if (entity.props.name === key) {
          entity.onStoreChange();
        }
      });
    });
  };

  // todo 作业
  validate = () => {
    let err = [];

    // todo校验

    return err;
  };

  submit = () => {
    let err = this.validate();
    if (err.length === 0) {
      // 校验通过
      this.callbacks.onFinish(this.getFieldsValue());
    } else {
      // 校验不通过
      this.callbacks.onFinishFailed(err, this.getFieldsValue());
    }
  };

  getForm = () => {
    return {
      getFieldsValue: this.getFieldsValue,
      getFieldValue: this.getFieldValue,
      setFieldsValue: this.setFieldsValue,
      registerFieldEntities: this.registerFieldEntities,
      setCallbacks: this.setCallbacks,
      submit: this.submit,
    };
  };
}

export default function useForm(form) {
  // 把formStore存起来，保证在父组件的任何一个生命周期里，formStore都是同一个值
  const formRef = useRef();
  if (!formRef.current) {
    if (form) {
      formRef.current = form;
    } else {
      const formStore = new FormStore();
      formRef.current = formStore.getForm();
    }
  }

  return [formRef.current];
}
