import useForm from "./useForm";
import FieldContext from "./FieldContext";
import React from "react";

export default function Form(
  { children, form, onFinish, onFinishFailed },
  ref
) {
  const [formInstance] = useForm(form); //form;
  formInstance.setCallbacks({ onFinish, onFinishFailed });

  React.useImperativeHandle(ref, () => formInstance);

  console.log("formInstance", form); //sy-log
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        formInstance.submit();
      }}
    >
      <FieldContext.Provider value={formInstance}>
        {children}
      </FieldContext.Provider>
    </form>
  );
}
