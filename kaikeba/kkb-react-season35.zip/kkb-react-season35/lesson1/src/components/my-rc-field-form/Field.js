import React, { Component } from "react";
import FieldContext from "./FieldContext";

export default class Field extends Component {
  static contextType = FieldContext;

  componentDidMount() {
    this.unregisterFieldEntities = this.context.registerFieldEntities(this);
  }

  componentWillUnmount() {
    this.unregisterFieldEntities();
  }

  onStoreChange = () => {
    this.forceUpdate();
  };

  getControlled = () => {
    const { name } = this.props;
    const { getFieldValue, setFieldsValue } = this.context;

    return {
      value: getFieldValue(name), //"omg", //state  get(name)
      onChange: (e) => {
        // 修改state set({name: value})
        const newValue = e.target.value;
        setFieldsValue({ [name]: newValue });
      },
    };
  };
  render() {
    const returnChildNode = React.cloneElement(
      this.props.children,
      this.getControlled()
    );
    return returnChildNode;
  }
}
