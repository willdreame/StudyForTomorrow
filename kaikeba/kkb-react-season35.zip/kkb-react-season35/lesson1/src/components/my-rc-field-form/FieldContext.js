import React from "react";

// 跨层级组件通信context

// 如何使用context

// 1. 创建context对象

const FieldContext = React.createContext();
export default FieldContext;

// 2. 通过Provider传递value

// 3. 消费value
// 1）ContextType 只能用在类组件中，并且只能订阅单一的context来源
// 2)Consumer 无限制，但是注意使用方式
// 3)useContext 只能用在函数组件或者自定义hook中
