// 更新vnode
// 更新dom

import {
  updateFunctionComponent,
  updateHostComponent,
  updateFragmentComponent,
} from "./ReactFiberReconciler";
import {scheduleCallback, shouldYield} from "./scheduler";
import {isStr, isFn, Placement, Update, updateNode} from "./utils";

// work in progress 当前正在工作当中的 wip
let wipRoot = null;
let nextUnitOfWork = null;
export function scheduleUpdateOnFiber(fiber) {
  fiber.alternate = {...fiber};

  wipRoot = fiber;
  nextUnitOfWork = wipRoot;

  scheduleCallback(workLoop);
}

function performUnitOfWork(wip) {
  const {type} = wip;
  // 1. 更新当前fiber
  if (isStr(type)) {
    // host
    updateHostComponent(wip);
  } else if (isFn(type)) {
    updateFunctionComponent(wip);
  } else {
    updateFragmentComponent(wip);
  }
  //2. 返回下一个要更新的fiber
  // 深度优先 王朝的故事
  if (wip.child) {
    return wip.child;
  }
  while (wip) {
    if (wip.sibling) {
      return wip.sibling;
    }
    wip = wip.return;
  }
  return null;
}

function workLoop() {
  while (nextUnitOfWork && !shouldYield()) {
    nextUnitOfWork = performUnitOfWork(nextUnitOfWork);
  }

  if (!nextUnitOfWork && wipRoot) {
    // vnode更新完了
    commitRoot();
  }
}

// requestIdleCallback(workLoop);

function commitRoot() {
  isFn(wipRoot.type) ? commitWorker(wipRoot) : commitWorker(wipRoot.child);
}

function commitWorker(wip) {
  if (!wip) {
    return;
  }
  // 1. commit自己
  const {flags, stateNode} = wip;
  // 父dom节点
  let parentNode = getParentNode(wip.return); //wip.return.stateNode;

  if (flags & Placement && stateNode) {
    parentNode.appendChild(stateNode);
  }
  if (flags & Update && stateNode) {
    updateNode(stateNode, wip.alternate.props, wip.props);
  }
  // 2. commit child
  commitWorker(wip.child);
  // 3. commit sibling
  commitWorker(wip.sibling);
}

function getParentNode(wip) {
  while (wip) {
    if (wip.stateNode) {
      return wip.stateNode;
    }
    wip = wip.return;
  }
}
