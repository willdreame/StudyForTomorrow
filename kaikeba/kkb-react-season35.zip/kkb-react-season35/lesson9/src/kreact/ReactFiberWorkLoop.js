// 更新vnode
// 更新dom

import {
  updateFunctionComponent,
  updateHostComponent,
  updateFragmentComponent,
} from "./ReactFiberReconciler";
import {scheduleCallback, shouldYield} from "./scheduler";
import {isStr, isFn, Placement, Update, updateNode} from "./utils";

// work in progress 当前正在工作当中的 wip
let wipRoot = null;
let nextUnitOfWork = null;
export function scheduleUpdateOnFiber(fiber) {
  fiber.alternate = {...fiber};

  wipRoot = fiber;
  nextUnitOfWork = wipRoot;

  scheduleCallback(workLoop);
}

function performUnitOfWork(wip) {
  const {type} = wip;
  // 1. 更新当前fiber
  if (isStr(type)) {
    // host
    updateHostComponent(wip);
  } else if (isFn(type)) {
    updateFunctionComponent(wip);
  } else {
    updateFragmentComponent(wip);
  }
  //2. 返回下一个要更新的fiber
  // 深度优先 王朝的故事
  if (wip.child) {
    return wip.child;
  }
  while (wip) {
    if (wip.sibling) {
      return wip.sibling;
    }
    wip = wip.return;
  }
  return null;
}

function workLoop() {
  while (nextUnitOfWork && !shouldYield()) {
    nextUnitOfWork = performUnitOfWork(nextUnitOfWork);
  }

  if (!nextUnitOfWork && wipRoot) {
    // vnode更新完了
    commitRoot();
  }
}

// requestIdleCallback(workLoop);

function commitRoot() {
  isFn(wipRoot.type) ? commitWorker(wipRoot) : commitWorker(wipRoot.child);
}

function invokeHooks(wip) {
  const {updateQueueOfEffect, updateQueueOfLayout} = wip;

  for (let i = 0; i < updateQueueOfLayout.length; i++) {
    const effect = updateQueueOfLayout[i];
    effect.create();
  }

  for (let i = 0; i < updateQueueOfEffect.length; i++) {
    const effect = updateQueueOfEffect[i];
    scheduleCallback(() => {
      effect.create();
    });
  }
}
function commitWorker(wip) {
  if (!wip) {
    return;
  }
  if (isFn(wip.type)) {
    invokeHooks(wip);
  }
  // 1. commit自己
  const {flags, stateNode} = wip;
  // 父dom节点
  let parentNode = getParentNode(wip.return); //wip.return.stateNode;

  // if (flags & Placement && stateNode) {
  //   parentNode.appendChild(stateNode);
  // }

  // 插入
  if (flags & Placement && stateNode) {
    let hasSiblingNode = foundSiblingNode(wip, parentNode);
    if (hasSiblingNode) {
      parentNode.insertBefore(stateNode, hasSiblingNode);
    } else {
      parentNode.appendChild(wip.stateNode);
    }
  }

  if (flags & Update && stateNode) {
    updateNode(stateNode, wip.alternate.props, wip.props);
  }

  // 检查wip有没有要删除的子节点
  if (wip.deletions) {
    commitDeletions(wip.deletions, stateNode || parentNode);
    wip.deletions = null;
  }

  // 2. commit child
  commitWorker(wip.child);
  // 3. commit sibling
  commitWorker(wip.sibling);
}

// 找后面最近的有dom节点的fiber
function foundSiblingNode(fiber, parentNode) {
  let siblingHasNode = fiber.sibling;
  let node = null;
  while (siblingHasNode) {
    node = siblingHasNode.stateNode;
    if (node && parentNode.contains(node)) {
      return node;
    }
    siblingHasNode = siblingHasNode.sibling;
  }

  return null;
}

function commitDeletions(deletions, parentNode) {
  for (let i = 0; i < deletions.length; i++) {
    const element = deletions[i];
    parentNode.removeChild(getStateNode(element));
  }
}

function getStateNode(fiber) {
  while (!fiber.stateNode) {
    fiber = fiber.child;
  }

  return fiber.stateNode;
}
function getParentNode(wip) {
  while (wip) {
    if (wip.stateNode) {
      return wip.stateNode;
    }
    wip = wip.return;
  }
}
