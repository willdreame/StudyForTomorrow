import React from 'react';
import styles from './index.less';

export default function Page() {
  return (
    <div>
      <h1 className={styles.title}>Page 404/index</h1>
    </div>
  );
}
