import React from 'react';
import styles from './about.css';

export default function Page() {
  return (
    <div>
      <h1 className={styles.title}>Page about</h1>
    </div>
  );
}
