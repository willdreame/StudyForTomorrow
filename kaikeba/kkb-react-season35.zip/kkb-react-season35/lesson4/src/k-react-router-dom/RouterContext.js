import React from "react";

const RouterContext = React.createContext();
export default RouterContext;
