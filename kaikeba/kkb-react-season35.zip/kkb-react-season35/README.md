step1. git clone https://github.com/bubucuo/kkb-react.git
step2. 切换对应分支



1. 课堂代码github地址： https://github.com/bubucuo/kkb-react
2. 课堂代码码云地址：https://gitee.com/bubucuo/kkb-react
