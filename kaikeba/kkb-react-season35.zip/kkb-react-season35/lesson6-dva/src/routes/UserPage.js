import { Component } from "react";
import { connect } from "dva";

@connect(state => {
  console.log("user all state", state); //sy-log
  return { user: state.user };
})
class UserPage extends Component {
  render() {
    console.log("user props", this.props); //sy-log
    return (
      <div>
        <h3>UserPage</h3>
      </div>
    );
  }
}
export default UserPage;
