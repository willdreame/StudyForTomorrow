import {useEffect, useLayoutEffect, useReducer} from "react";
import {countReducer} from "../store";

const init = (initalArg) => initalArg - 0;

function HooksPage(props) {
  const [count, setCount] = useReducer(countReducer, "0", init);
  const [count2, setCount2] = useReducer(countReducer, "0", init);

  useEffect(() => {
    console.log("useEffect"); //sy-log
    return () => {
      console.log("useEffect unmount"); //sy-log
    };
  }, [count]);

  useLayoutEffect(() => {
    console.log("useLayoutEffect"); //sy-log
    return () => {
      console.log("useLayoutEffect unmount"); //sy-log
    };
  }, [count]);
  return (
    <div>
      <h3>HooksPage</h3>
      <button onClick={() => setCount({type: "ADD"})}>{count}</button>
      <button onClick={() => setCount2({type: "ADD"})}>{count2}</button>
    </div>
  );
}
export default HooksPage;
