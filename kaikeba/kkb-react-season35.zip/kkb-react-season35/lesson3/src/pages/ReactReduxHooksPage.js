// import {useDispatch, useSelector} from "react-redux";
import {useCallback} from "react";
import {useDispatch, useSelector} from "../kReactRedux";

function ReactReduxHooksPage(props) {
  const count = useSelector(({count}) => count);
  const dispatch = useDispatch();
  const handle = useCallback(() => {
    dispatch({type: "ADD"});
  }, []);
  return (
    <div>
      <h3>ReactReduxHooksPage</h3>
      <button onClick={handle}>{count}</button>
    </div>
  );
}
export default ReactReduxHooksPage;
