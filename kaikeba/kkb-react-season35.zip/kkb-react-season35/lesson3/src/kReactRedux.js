// Provider
import React, {
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useReducer,
  useState,
} from "react";
// context跨层级数据传递

//* 1. 创建context对象

const Context = React.createContext();

// *2、 Provider传递value store
export function Provider({children, store}) {
  return <Context.Provider value={store}>{children}</Context.Provider>;
}
// connect
//* 3 子孙组件消费store
export const connect = (mapStateToProps, mapDispatchToProps) => (
  WrappedComponent
) => (props) => {
  const store = useContext(Context);
  const stateProps = mapStateToProps(store.getState());
  let dispatchProps = {dispatch: store.dispatch};

  if (typeof mapDispatchToProps === "function") {
    dispatchProps = mapDispatchToProps(store.dispatch);
  } else if (typeof mapDispatchToProps === "object") {
    dispatchProps = bindActionCreators(mapDispatchToProps, store.dispatch);
  }
  // const [, forceUpdate] = useState(0); //useReducer((x) => x + 1, 0);

  const forceUpdate = useForceUpdate();

  useLayoutEffect(() => {
    const unsubscribe = store.subscribe(() => {
      forceUpdate();
    });

    return () => {
      unsubscribe();
    };
  }, [store]);

  return <WrappedComponent {...props} {...stateProps} {...dispatchProps} />;
};

function useForceUpdate() {
  const [, setState] = useReducer((x) => x + 1, 0);

  const update = useCallback(() => {
    setState();
  }, []);

  return update;
}

function bindActionCreator(creator, dispatch) {
  return (...args) => dispatch(creator(...args));
}

export function bindActionCreators(creators, dispatch) {
  let obj = {};

  for (let key in creators) {
    obj[key] = bindActionCreator(creators[key], dispatch);
  }
  return obj;
}

// hooks

export function useDispatch() {
  const store = useContext(Context);
  return store.dispatch;
}

export function useSelector(selector) {
  const store = useContext(Context);
  const selectedState = selector(store.getState());

  const forceUpdate = useForceUpdate();

  useLayoutEffect(() => {
    const unsubscribe = store.subscribe(() => {
      forceUpdate();
    });

    return () => {
      unsubscribe();
    };
  }, [store]);

  return selectedState;
}
