import {createStore, applyMiddleware, combineReducers} from "redux";
// import thunk from "redux-thunk";
// import logger from "redux-logger";
// import promise from "redux-promise";
import isPromise from "is-promise";

// import {createStore, applyMiddleware} from "../kredux/";

// 定义修改规则
function countReducer(state = 0, action) {
  switch (action.type) {
    case "ADD":
      return state + 1;
    case "MINUS":
      return state - action.payload || 1;
    default:
      return state;
  }
}

// 创建一个数据仓库
const store = createStore(
  // countReducer,
  combineReducers({count: countReducer}),
  applyMiddleware(thunk, promise, logger)
);

export default store;

// wrapper function
function logger({dispatch, getState}) {
  return (next) => (action) => {
    console.log("logger next", next); //sy-log

    console.log("------------------------------------"); //sy-log
    console.log(action.type + "执行了！"); //sy-log
    const prevState = getState();
    console.log("prev state", prevState); //sy-log
    const returnValue = next(action);
    const nextState = getState();
    console.log("next state", nextState); //sy-log
    console.log("------------------------------------"); //sy-log
    return returnValue;
  };
}

function thunk({dispatch, getState}) {
  return (next) => (action) => {
    console.log("thunk next", next); //sy-log
    if (typeof action === "function") {
      return action(dispatch, getState);
    }
    return next(action);
  };
}

function promise({dispatch, getState}) {
  return (next) => (action) => {
    return isPromise(action) ? action.then(dispatch) : next(action);
  };
}
