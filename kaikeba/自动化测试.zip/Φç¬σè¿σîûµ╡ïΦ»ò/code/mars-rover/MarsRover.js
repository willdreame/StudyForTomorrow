const { turnLeft,turnRight } = require("./directionMap");

class MarsRover {
  constructor(position, direction) {
    this.position = position;
    this.direction = direction;
  }

  turnLeft() {
    this.direction = turnLeft(this.direction);
  }

  turnRight() {
    this.direction = turnRight(this.direction);
  }
  getState() {
    return {
      position: {
        x: this.position.x,
        y: this.position.y,
      },
      direction: this.direction,
    };
  }
}

module.exports = { MarsRover };
