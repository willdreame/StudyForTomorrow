const { Direction } = require("./direction");

const mapLeft = {
  [Direction.N]: Direction.W,
  [Direction.W]: Direction.S,
  [Direction.S]: Direction.E,
  [Direction.E]: Direction.N,
};

const mapRight = {
  [Direction.N]: Direction.E,
  [Direction.E]: Direction.S,
  [Direction.S]: Direction.W,
  [Direction.W]: Direction.N,
};

function turnLeft(direction) {
  return mapLeft[direction];
}

function turnRight(direction) {
  return mapRight[direction];
}

module.exports = {
  turnLeft,
  turnRight,
};
