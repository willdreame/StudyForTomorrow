const Direction = {
  N: "n",
  W: "w",
  S: "s",
  E: "e",
};

module.exports = {
  Direction,
};
