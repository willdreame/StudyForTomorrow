const { MarsRover } = require("./MarsRover");
const { Position } = require("./Position");
const { Direction } = require("./direction");

test("init should return position and direction ", () => {
  const marsRover = new MarsRover(new Position(0, 0), Direction.N);

  expect(marsRover.getState()).toEqual({
    position: {
      x: 0,
      y: 0,
    },
    direction: Direction.N,
  });
});

describe("turnLeft", () => {
  it("n->w", () => {
    const marsRover = new MarsRover(new Position(0, 0), Direction.N);

    // when
    marsRover.turnLeft();

    expect(marsRover.getState()).toEqual({
      position: {
        x: 0,
        y: 0,
      },
      direction: Direction.W,
    });
  });

  it("W->S", () => {
    const marsRover = new MarsRover(new Position(0, 0), Direction.W);

    // when
    marsRover.turnLeft();

    expect(marsRover.getState()).toEqual({
      position: {
        x: 0,
        y: 0,
      },
      direction: Direction.S,
    });
  });

  it("S->E", () => {
    const marsRover = new MarsRover(new Position(0, 0), Direction.S);

    // when
    marsRover.turnLeft();

    expect(marsRover.getState()).toEqual({
      position: {
        x: 0,
        y: 0,
      },
      direction: Direction.E,
    });
  });

  it("E->N", () => {
    const marsRover = new MarsRover(new Position(0, 0), Direction.E);

    // when
    marsRover.turnLeft();

    expect(marsRover.getState()).toEqual({
      position: {
        x: 0,
        y: 0,
      },
      direction: Direction.N,
    });
  });
});

describe("turnRight", () => {
  it("n->e", () => {
    const marsRover = new MarsRover(new Position(0, 0), Direction.N);

    // when
    marsRover.turnRight();

    expect(marsRover.getState()).toEqual({
      position: {
        x: 0,
        y: 0,
      },
      direction: Direction.E,
    });
  });

  it("E->S", () => {
    const marsRover = new MarsRover(new Position(0, 0), Direction.E);

    // when
    marsRover.turnRight();

    expect(marsRover.getState()).toEqual({
      position: {
        x: 0,
        y: 0,
      },
      direction: Direction.S,
    });
  });

  it("S->W", () => {
    const marsRover = new MarsRover(new Position(0, 0), Direction.S);

    // when
    marsRover.turnRight();

    expect(marsRover.getState()).toEqual({
      position: {
        x: 0,
        y: 0,
      },
      direction: Direction.W,
    });
  });

  it("W->N", () => {
    const marsRover = new MarsRover(new Position(0, 0), Direction.W);

    // when
    marsRover.turnRight();

    expect(marsRover.getState()).toEqual({
      position: {
        x: 0,
        y: 0,
      },
      direction: Direction.N,
    });
  });
});
