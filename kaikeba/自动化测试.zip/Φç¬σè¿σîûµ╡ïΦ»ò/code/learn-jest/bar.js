function bar() {
  console.log("bar");
}


module.exports = {
	bar
}
