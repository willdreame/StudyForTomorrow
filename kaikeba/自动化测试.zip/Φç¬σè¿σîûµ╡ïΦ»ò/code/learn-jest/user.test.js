const { User } = require("./User");

test("User", () => {
  // given
  const user = new User("xiaohei");
  // when
  user.setName("xiaohong");
  // then
  expect(user.name).toBe("xiaohong");
});
