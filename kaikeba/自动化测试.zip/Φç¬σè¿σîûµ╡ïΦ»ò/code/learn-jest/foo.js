const { bar } = require("./bar");

function foo() {
  bar();
}

module.exports = {
  foo,
};
