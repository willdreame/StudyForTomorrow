const { foo } = require("./foo");
const { bar } = require("./bar");

jest.mock("./bar.js", () => {
  return {
    bar: jest.fn(),
  };
});

test("should call bar function", () => {
  // when
  foo();
  console.log(bar);
  expect(bar).toBeCalled();

  // then

  // expect()
});
