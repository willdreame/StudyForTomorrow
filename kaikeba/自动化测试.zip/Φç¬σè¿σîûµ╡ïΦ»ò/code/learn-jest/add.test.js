const { add } = require("./add");


// function
// input
//  args
// output
// 1. return value
// 2. call other function
// 3. change state

test("add 1+1 = 2 ", () => {
  // 1. 准备数据 -- given
  const a = 1;
  const b = 1;

  // 2. 触发测试动作 -- when
  const r = add(a, b);

  // toBe 匹配器
  // 3. 验证 -- then
  expect(r).toBe(2);
});
